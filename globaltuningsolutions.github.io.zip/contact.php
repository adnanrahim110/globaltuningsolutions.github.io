<?php
$title = "Contact";
$hero_banner = "contact_page";
$hero_title = "Contact us";
$hero_desc = "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quae perferendis voluptas sint repellendus dignissimos magnam similique quisquam sapiente alias unde?"
?>

<?php include "includes/head.php"; ?>

<body>
    <?php include "includes/navbar.php"; ?>
    <main>
        <?php include "includes/hero_sec.php"; ?>
        <?php include "includes/contact_form.php"; ?>
    </main>
    <?php include "includes/footer.php"; ?>